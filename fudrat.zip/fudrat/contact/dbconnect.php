<?php

//connect the form to database by creating connecting variables

$dbhost = "localhost";
$dbuser = "root";
$dbpass = "1234567890";
$dbname = "demo";

// now create connection

$dbconnect = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

// create connection errors messages

if(mysqli_connect_error()){
    echo "failed to connect to database" .mysqli_connect_error();
}else{
    // echo "connection successful";
}

?>