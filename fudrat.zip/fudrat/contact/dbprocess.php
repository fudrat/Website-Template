<?php

    // include the dbconnect file to the page

    include("dbconnect.php");

    //create variables to link to the form inputs

    $firstname = $_REQUEST["firstname"];
    $lastname = $_REQUEST["lastname"];
    $email = $_REQUEST["email"];
    $date = $_REQUEST["dob"];
    $course = $_REQUEST["course"];
    $user_message = $_REQUEST["user_message"];

    //create sql query 

    $sql = mysqli_query($dbconnect, "INSERT INTO message(firstname, lastname, email, dob, course, user_message) VALUES('$firstname', '$lastname', '$email', '$date', '$course', '$user_message')") or die(mysqli_error($dbconnect));


    // close database connection

    mysqli_close($dbconnect);

    //redirect to the index page

    header("location:formOne.php?note=success");

?>